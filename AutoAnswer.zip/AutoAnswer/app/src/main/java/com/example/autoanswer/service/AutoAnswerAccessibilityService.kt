package com.example.autoanswer.service

import android.accessibilityservice.AccessibilityService
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.example.autoanswer.data.ServiceLocator
import kotlinx.coroutines.*

class AutoAnswerAccessibilityService : AccessibilityService() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var job: Job? = null
    private var lastQuestion: String? = null

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!ServiceLocator.prefs.enabled) return
        // Debounce: so processa quando a tela assenta
        job?.cancel()
        job = scope.launch {
            delay(700)
            process()
        }
    }

    private suspend fun process() {
        val prefs = ServiceLocator.prefs
        val qId = prefs.questionId
        if (qId.isBlank()) return

        val root = rootInActiveWindow ?: return
        val question = root.findAccessibilityNodeInfosByViewId(qId)
            .firstOrNull()?.text?.toString()?.trim()
        if (question.isNullOrBlank() || question == lastQuestion) return

        val input = findInput(root) ?: return
        if (!input.text.isNullOrBlank()) return // ja preenchido: evita loop

        lastQuestion = question
        val answer = ServiceLocator.repo.ask(question) ?: return

        // O no pode ter ficado obsoleto durante a chamada: busca de novo
        val freshRoot = rootInActiveWindow ?: return
        val freshInput = findInput(freshRoot) ?: return
        freshInput.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, answer)
        }
        freshInput.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    private fun findInput(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val id = ServiceLocator.prefs.inputId
        if (id.isNotBlank()) return root.findAccessibilityNodeInfosByViewId(id).firstOrNull()
        return firstEditable(root)
    }

    private fun firstEditable(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isEditable) return node
        for (i in 0 until node.childCount) {
            val found = node.getChild(i)?.let { firstEditable(it) }
            if (found != null) return found
        }
        return null
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
