package com.example.autoanswer.data

import android.content.Context
import com.example.autoanswer.data.local.AppDatabase
import com.example.autoanswer.data.remote.GeminiApi
import com.example.autoanswer.data.repository.AnswerRepository
import com.example.autoanswer.util.SecurePrefs
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

object ServiceLocator {
    lateinit var prefs: SecurePrefs; private set
    lateinit var repo: AnswerRepository; private set

    fun init(context: Context) {
        val app = context.applicationContext
        prefs = SecurePrefs(app)
        val http = OkHttpClient.Builder().callTimeout(30, TimeUnit.SECONDS).build()
        val api = Retrofit.Builder()
            .baseUrl("https://generativelanguage.googleapis.com/")
            .client(http)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(GeminiApi::class.java)
        repo = AnswerRepository(api, AppDatabase.create(app).logDao(), prefs)
    }
}
