package com.example.autoanswer

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.autoanswer.data.ServiceLocator
import kotlinx.coroutines.launch
import java.text.DateFormat
import java.util.Date

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Root() } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Root() {
    var tab by remember { mutableIntStateOf(0) }
    Scaffold(topBar = { TopAppBar(title = { Text("AutoAnswer") }) }) { pad ->
        Column(Modifier.padding(pad)) {
            TabRow(selectedTabIndex = tab) {
                Tab(tab == 0, { tab = 0 }, text = { Text("Configuracoes") })
                Tab(tab == 1, { tab = 1 }, text = { Text("Logs") })
            }
            if (tab == 0) SettingsScreen() else LogsScreen()
        }
    }
}

@Composable
fun SettingsScreen() {
    val ctx = LocalContext.current
    val prefs = ServiceLocator.prefs
    var apiKey by remember { mutableStateOf(prefs.apiKey) }
    var qId by remember { mutableStateOf(prefs.questionId) }
    var inId by remember { mutableStateOf(prefs.inputId) }
    var instr by remember { mutableStateOf(prefs.instruction) }
    var enabled by remember { mutableStateOf(prefs.enabled) }

    Column(
        Modifier.padding(16.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        OutlinedTextField(apiKey, { apiKey = it }, label = { Text("Gemini API key") },
            visualTransformation = PasswordVisualTransformation(), singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(qId, { qId = it }, label = { Text("ID da pergunta (pacote:id/nome)") },
            singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(inId, { inId = it }, label = { Text("ID do campo de resposta (opcional)") },
            singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(instr, { instr = it }, label = { Text("Instrucao para a IA") }, modifier = Modifier.fillMaxWidth())
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Ativar preenchimento automatico", Modifier.weight(1f))
            Switch(enabled, { enabled = it })
        }
        Button({
            prefs.apiKey = apiKey.trim(); prefs.questionId = qId.trim(); prefs.inputId = inId.trim()
            prefs.instruction = instr; prefs.enabled = enabled
        }, Modifier.fillMaxWidth()) { Text("Salvar") }
        OutlinedButton({
            ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }, Modifier.fillMaxWidth()) { Text("Abrir configuracoes de acessibilidade") }
        Text(
            "O pacote monitorado e com.everyward.app. Para achar os IDs das views, use o Layout Inspector do Android Studio ou o uiautomatorviewer.",
            style = MaterialTheme.typography.bodySmall
        )
    }
}

@Composable
fun LogsScreen() {
    val repo = ServiceLocator.repo
    val logs by repo.logs.collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    val fmt = remember { DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.MEDIUM) }
    Column(Modifier.padding(16.dp)) {
        TextButton({ scope.launch { repo.clearLogs() } }) { Text("Limpar logs") }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(logs) { l ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text(fmt.format(Date(l.time)), style = MaterialTheme.typography.labelSmall)
                        Text("P: ${l.question}")
                        Text(if (l.error != null) "Erro: ${l.error}" else "R: ${l.answer}")
                    }
                }
            }
        }
    }
}
