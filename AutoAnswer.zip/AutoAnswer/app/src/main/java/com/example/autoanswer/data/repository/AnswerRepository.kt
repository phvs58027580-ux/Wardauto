package com.example.autoanswer.data.repository

import com.example.autoanswer.data.local.LogDao
import com.example.autoanswer.data.local.LogEntry
import com.example.autoanswer.data.remote.*
import com.example.autoanswer.util.SecurePrefs

class AnswerRepository(
    private val api: GeminiApi,
    private val dao: LogDao,
    private val prefs: SecurePrefs
) {
    val logs = dao.observe()
    suspend fun clearLogs() = dao.clear()

    suspend fun ask(question: String): String? {
        val key = prefs.apiKey
        if (key.isBlank()) {
            dao.insert(LogEntry(time = now(), question = question, answer = null, error = "API key nao configurada"))
            return null
        }
        return try {
            val prompt = "${prefs.instruction}\n\n$question"
            val res = api.generate(MODEL, key, GeminiRequest(listOf(Content(listOf(Part(prompt))))))
            val text = res.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text?.trim()
            dao.insert(LogEntry(time = now(), question = question, answer = text, error = if (text == null) "Resposta vazia" else null))
            text
        } catch (e: Exception) {
            dao.insert(LogEntry(time = now(), question = question, answer = null, error = e.message ?: e.javaClass.simpleName))
            null
        }
    }

    private fun now() = System.currentTimeMillis()
    companion object { const val MODEL = "gemini-2.5-flash" }
}
