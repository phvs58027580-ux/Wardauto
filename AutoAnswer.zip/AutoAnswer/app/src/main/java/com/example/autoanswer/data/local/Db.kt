package com.example.autoanswer.data.local

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "logs")
data class LogEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val time: Long,
    val question: String,
    val answer: String?,
    val error: String?
)

@Dao
interface LogDao {
    @Insert suspend fun insert(e: LogEntry)
    @Query("SELECT * FROM logs ORDER BY time DESC LIMIT 200") fun observe(): Flow<List<LogEntry>>
    @Query("DELETE FROM logs") suspend fun clear()
}

@Database(entities = [LogEntry::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun logDao(): LogDao
    companion object {
        fun create(c: Context) = Room.databaseBuilder(c, AppDatabase::class.java, "autoanswer.db").build()
    }
}
