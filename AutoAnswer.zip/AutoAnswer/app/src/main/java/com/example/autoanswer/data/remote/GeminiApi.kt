package com.example.autoanswer.data.remote

import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST
import retrofit2.http.Path

data class Part(val text: String)
data class Content(val parts: List<Part>)
data class GeminiRequest(val contents: List<Content>)
data class Candidate(val content: Content?)
data class GeminiResponse(val candidates: List<Candidate>?)

interface GeminiApi {
    @POST("v1beta/models/{model}:generateContent")
    suspend fun generate(
        @Path("model") model: String,
        @Header("x-goog-api-key") apiKey: String,
        @Body body: GeminiRequest
    ): GeminiResponse
}
