package com.example.autoanswer

import android.app.Application
import com.example.autoanswer.data.ServiceLocator

class AutoAnswerApp : Application() {
    override fun onCreate() {
        super.onCreate()
        ServiceLocator.init(this)
    }
}
