package com.example.autoanswer.util

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

class SecurePrefs(context: Context) {
    private val prefs: SharedPreferences = run {
        val key = MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        EncryptedSharedPreferences.create(
            context, "secure_prefs", key,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    var apiKey: String
        get() = prefs.getString("api_key", "") ?: ""
        set(v) = prefs.edit().putString("api_key", v).apply()

    // ID completo, ex.: com.everyward.app:id/question
    var questionId: String
        get() = prefs.getString("question_id", "") ?: ""
        set(v) = prefs.edit().putString("question_id", v).apply()

    // Vazio = usa o primeiro campo editavel da tela
    var inputId: String
        get() = prefs.getString("input_id", "") ?: ""
        set(v) = prefs.edit().putString("input_id", v).apply()

    var instruction: String
        get() = prefs.getString("instruction", "Responda de forma curta e direta:") ?: ""
        set(v) = prefs.edit().putString("instruction", v).apply()

    var enabled: Boolean
        get() = prefs.getBoolean("enabled", false)
        set(v) = prefs.edit().putBoolean("enabled", v).apply()
}
